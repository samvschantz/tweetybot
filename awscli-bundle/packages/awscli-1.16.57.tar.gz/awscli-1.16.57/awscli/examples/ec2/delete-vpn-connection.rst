**To delete a VPN connection**

This example deletes the specified VPN connection. If the command succeeds, no output is returned.

Command::

  aws ec2 delete-vpn-connection --vpn-connection-id vpn-40f41529
